drupal for firebug 
----------------------
matt cheney (populist)
matt@chapterthree.com
----------------------

-- to use this module you must also download and install the drupal for firebug firefox extension. the extension is now public and available at https://addons.mozilla.org/en-US/firefox/addon/8370.

-- to see this module in action (after installing the firefox extension), check out the demonstration test site at http://drupalforfirebug.chapterthree.com/tests.

-- this module requires more memory than normal. a good rule of thumb is to set the memory at 96M. information on how to increase the memory is here: http://drupal.org/node/29268

more information about the module available at:
http://drupalforfirebug.chapterthree.com
http://www.drupal.org/project/drupalforfirebug
